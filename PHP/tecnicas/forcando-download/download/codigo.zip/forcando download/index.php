<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-br">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Forçando download</title>

</head>
<body>

<h1>Forçando download</h1>
<p>Técnica para forçar download do arquivo específicado. Para mais detalhes veja o código fonte.</p>

<h2>Resultado</h2>
<p>Faça download desse <a href="?act=down">código</a>.</p>

</body>
</html>
