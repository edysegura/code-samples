<?php
if(isset($_GET['act'])&&$_GET['act']=="down")
{
	$vo_arquivo = "../downlaod/codigo.zip";
	//headers
	header("content-description: File Transfer");
	header("content-type: application/force-download");
	header("content-disposition: attachment;filename=".basename($vo_arquivo));
	//lendo o arquivo
	@readfile($vo_arquivo);
}
?>